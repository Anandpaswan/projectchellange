<?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
    $customer_name=$_POST['pname'];
    $mobile=$_POST['mobile'];
    $email_id=$_POST['email'];
    $bill_no="BILLNO".time().mt_rand(100,999);
   
   
      
    require_once('db.php');

     $description="";
     $total=0;


    $fetch_data=$conn->query("SELECT * FROM billing_data");
    while($rw=$fetch_data->fetch_assoc())
    {
          $description.= $rw['product_name']."  ( ".$rw['quantity']." x  ".$rw['rate']." )  | ";
          $total+=$rw['quantity']*$rw['rate'];
    }
 
  
     $cmd="INSERT INTO user_info VALUES('$customer_name','$mobile','$email_id','$bill_no','$description',$total)";
  
    if($conn->query($cmd)==true)
    {
        $conn->query("delete from billing_data");
        header('location:billing_page.php?tok=data save');
    }
    else
    {
        header('location:billing_page.php?tok='.$conn->error);
    }

}
else
{
    header('location:billing_page.php?tok=Invalid request');
}
?>