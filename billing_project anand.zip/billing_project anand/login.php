<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Document</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/login.css">


<style>
    
    body{
        background: linear-gradient(to bottom,#072507,#19b919,#072507);
    }
    
    </style>
</head>

<body>

   <div class="text text-center mt-5">
   
   </div> 
   <div class="container">
    <div class="row justify-content-center">
            <div class="col-md-5  p-4 " style="">
        <?php
                    if(isset($_GET['token'])) {
                     if($_GET['token'] =="12345678") { ?>
                            <div class="alert alert-success mt-4 t">
                            <strong>Information</strong>
                            <span>login expired</span>
                        </div>  

                        <?php } elseif($_GET['token']=="684591234") { ?>
                            <div class="alert alert-danger mt-4">
                            <strong>error</strong>
                            <span>login failed</span>
                        </div>

                    <?php } else {  ?>

                        <div class="alert alert-danger mt-4">
                            <strong>error</strong>
                            <span><?php echo $_GET['token'];   ?></span>
                        </div>

                    <?php } }?>
             <div class="card mt-5 ">
                <div class="card-header bg-success text-white text-center">
                    <h3 class=""><i class="fa fa-lock"></i>Login Here</h3>
                </div>
                <div class="card-body">
                    <form method="post" action="login_back.php">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                   <i class="fa fa-envelope text-success"></i>
                                </span>
                            </div>
                            <input type="text" name="email" class="form-control" required placeholder="enter your email">
                        </div>

                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                <i class="fa fa-key text-success"></i></span>
                            </div>
                            <input type="text" name="password" class="form-control" required placeholder="password">
                        </div>
                        <button type="submit" class="btn btn-success btn-block b1">login</button>
                        <div class="text-center small  txt">already a member? <a href="" class="text-success">login here</a></div>

                    </form>
                </div>
            </div>
            
        </div>
        <!-- <div class="col-3"></div> -->
    </div>
   </div>
</body>
</html>