<?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
    $t1=$_POST['product'];
    $t2=$_POST['rate'];
    $t3=$_POST['quantity'];
   
	
   
      
    require_once('db.php');
  
$cmd="Insert into billing_data(product_name,rate,quantity) values('$t1','$t2','$t3')";
  
    if($conn->query($cmd))
    {
        header('location:billing_page.php?tok=data save');
    }
    else
    {
        header('location:billing_page.php?tok='.$conn->error);
    }

}
else
{
    header('location:billing_page.php?tok=Invalid request');
}
?>