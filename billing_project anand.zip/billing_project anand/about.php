<!DOCTYPE html>
<html>
<head>
	<title>About</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
           .style1 {
			width: 50%;
			height: 50vh;
			background: url(image/image_processing20200414-2665-j5twpn.gif);
			background-size: cover;
		

		}
        body{
            background: linear-gradient(to right,#072507,#19b919);
          
            }
            
            .card-header{
                 font-size: 30px;
                text-transform: uppercase;
                background-image: linear-gradient(to left, green, black, green);
            }
    </style>
</head>

    <body>
      
      
        <div class="card-header justify-content-center text-light">
      <marquee>  <label class="">        About Content</label></marquee>
    </div>
    <div class="container">

        <div class="row  mt-5 ">
            <div class="col-md-4  style1">
                
    </div>
    
    
    <div class="col-md-8  text-light">
        <p>
        The project “Billing system” is an application to automate the process of ordering
And billing of a restaurant .This application is developed for the established restaurants in the city to manage the billing operations. It has the entire basic module to operate the billing modules. This application also administrates its users and customers.
This project will serve the following objectives:-<br>
•	 Add and maintain records of available products.<br>
•	 Add and maintain customer details.<br>
•	 Add and maintain description of new products.<br>
•	 Add and maintain admin and employee details.<br>
•	 Provides a convenient solution of billing pattern.<br>
•	 Make an easy to use environment for users and customers.<br>
•	Create membership for customers.<br>


    </p>
<hr>
<h4 class="text-info">For More Queries</h4>
<label class="text-danger">Developer Name: anand</label><br>
<label class="text-danger">Contact: 9027504145</label>
    </div>
    </div>
    </div>
    </body>
</html> 