

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	include('db.php');
    $email=$_POST['email'];
    $password = $_POST['password'];

	$cmd="SELECT * FROM admin_data WHERE email='$email' AND password='$password'";
	$results=$conn->query($cmd);
	if($results->num_rows>0){
		$data=$results->fetch_assoc();
		$_user_id=$data['user_id'];
		session_start();
		$_SESSION['user_id']=$_user_id;
		header('location: ./');
	}
	else{
		header('location:login.php?token=684591234');
}
	
}
else{
    header('location:login.php?token=684591234');
}


?>