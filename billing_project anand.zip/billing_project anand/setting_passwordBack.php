<?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
    
    $t1=$_POST['password'];
    $t2=$_POST['new_password'];
    $t3=$_POST['confirm_password'];

    session_start();
	$_user_id = $_SESSION['user_id'];


    require_once('db.php');

    $cmd="UPDATE admin_data SET password='$t2'  WHERE user_id='$_user_id' ";

    if($conn->query($cmd))
    {
        header('location:setting_paasword.php?tok=Update');
    }
    else
    {
        header('location:setting_paasword.php?tok='.$conn->error);
    }

}
else
{
    header('location:setting_paasword.php?tok=Invalid request');
}
?>


