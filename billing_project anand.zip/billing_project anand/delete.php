<?php
if($_SERVER['REQUEST_METHOD']=='GET')
{
    $t1=$_GET['name'];

    require_once('db.php');
    $cmd="DELETE FROM  billing_data where product_name='$t1' ";
    if($conn->query($cmd))
    {
        header('location:billing_page.php?tok=data deleted');
    }
    else
    {
        header('location:billing_page.php?tok='.$conn->error);
    }

}
else
{
    header('location:billing_page.php?tok=Invalid request');
}
?>