<!DOCTYPE html>
<html>
<head>
	<title>Billing</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
<div class=" card bg-success">
	<a class="navbar-brand text-center" href="#"><h1 class="text-light">Customer's Details	</h1></a>
		 </div>
		 <div class="card-body">

    <table class="table table-success" method="post" action="detail_log.php">
					<thead class="text-danger">
						<th>Customer's Name</th>
						
						<th>Mobile No.</th>
						<th>Bill No.</th>
						<th>Total Bill</th>
    

					</thead>
					<tbody >
					<?php
                          require_once('db.php');
                            $data=$conn->query("SELECT* FROM user_info");
                         

                            while($rw=$data->fetch_assoc())
                            {
							

                            ?>
                            <tr>
                                <td><?php echo $rw['coustomer_name']; ?></td>
                                <td><?php echo $rw['mobile']; ?></td>
                                <td><?php echo $rw['bill_no']; ?></td>
                                <td><?php echo $rw['total_bill']; ?></td>
                                <td>
                          
                                </td>
                            </tr>
                            <?php } ?>
					<tbody>
                       
                        </tbody>
				
			
				</table>

</div>





</body>
</html>