<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>



    body{
        background: linear-gradient(to bottom, aqua, rgb(0, 51, 51) );
    }
 
</style>
<body>
<div  onclick="history.back()" class="sum "> < Back</div>
    <div class="container vh-100 ">
     <div class="row justify-content-center h-100">
     
         <div class="card  my-auto shadow">
             <div class="card-header bg-info text-white" style="font-size:23px;">
                <h1 class="justify-content-center">Password Change Here</h1>
             </div>
              <div class="card-body ">
                 <form method="post" action="setting_passwordBack.php">
               
                     <div class="form-group">

                        
                       <i class="fa fa-key"></i>
                         <label class="text-info">Old Password Here </label>
                         

                        <input type="password"  
                         name="password" class="form-control"  placeholder="Type Old Password Here" 
                        required
                        />
                      
                    </div>
                    <div class="from-control">
                         <i class="fa fa-lock"></i>

                         <label class="text-info">New Password Here</label>
                         <input type="password" placeholder="Type New Password  Here"  
                         name="new_password" 
                         class="form-control" 
                        required
                           />
                    </div>
                    <div class="from-control">
                 <i class="fa fa-unlock"></i>

                 <label class="text-info">Re-Enter Password Here</label>
                 <input type="password" placeholder="Re-Enter Password Here"  
               name="confirm_password" 
               class="form-control" 
               required
              />
          </div>
          <input type="submit" class="btn btn-info w-100 mt-3" >
         
                            
        </form>
       

    
          
     
        </div>
        
    </div>
 </div>
       






</body>
</html>