<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
<script type="text/javascript">
    function setData(name)
    {
        fetch_Data(name);
    }
    async function fetch_Data(name)
    {
        console.log(name);  
        let rs=await fetch('http://localhost/fetch_data.php?name='+name)
        let data=await rs.json();
        console.log(data);
        document.getElementById("product").value=data[0].product_name;
        document.getElementById("rate").value=data[0].rate;
        document.getElementById("quantity").value=data[0].quantity;

        
        
    }
    </script>
</html>