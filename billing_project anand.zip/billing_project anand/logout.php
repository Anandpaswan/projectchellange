<?php
	session_start();
	$user_id=" ";
	if (isset($_SESSION['email']) && isset($_SESSION['password']))
	{
		$user = $_SESSION['email'];
	}
	else{
		header('location: login.php?tok= Login First');
	}
	
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<title>PageTitle</title>
	</head>
	<body>
		<h1><?php echo $user; ?>  </h1>
<a href="logout.php">LogOut</a>

	
	</body>
	</html>
