<?php
$conn=new mysqli("localhost","root","","stu_data");
?>