<?php
$product_name=$_GET['name'];
require_once('db.php');
$arr=array();
$data=$conn->query("select * from billing_data where name='$product_name' ");
while($rw=$data->fetch_assoc())
{
    $arr[]=$rw;
}
    


echo json_encode($arr);
?>