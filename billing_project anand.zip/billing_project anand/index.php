<?php
 session_start();
   $_user_id = " ";
   if (isset($_SESSION['user_id'])) {
		$_admin_id = $_SESSION['user_id'];
	
	}
		

	else {
				header("location:login.php?token=12345678");
		
	}
?>



<!DOCTYPE html>
<html>

<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<style type="text/css">
		body{
			background: linear-gradient(to left, #420f66 , #31c4c4, #010141, #c51414 );
    }
		
	@media screen and (max-width: 1000px) {
  
  .style2{
	
	margin-left: -230px;
	
	
  }
}
	</style>
</head>

<body>
	<nav class="navbar navbar-light ml-5 ">
		<div class="d-flex col-md-9 justify-content-center">
			<a class="navbar-brand" >
				<h3 class="text-light">Bill Dash Menu</h3>
			</a>


		</div>
		<div class="col-md-3 style2">
			<button type="submit" class="btn btn-success l-auto " style="margin-left:169px;"> <a href="logout_back.php" class="text-white ">LogOut</a>
			</button>
		</div>
		
	</nav>
	<div class="container vh-100">

		<div class="row justify-content-center h-100 ">
			<div class="col-md-3 my-auto shadow ">
				<div class="text-white p-5  " style=" border-radius:8px; background-color:indigo">
					<a href="billing_page.php"><i class="fa fa-calculator text-white">
							<h3 class="text-white  t1">Billing</h3>
						</i></a>
				</div>
				<hr>
				<div class="text-white  p-5 mt-4 my-auto shadow  " style="background-color: #00cccc;  border-radius:8px">
					<a href="setting_password.php"><i class="fa fa-cog text-white">
							<h3 class="text-white">Setting</h3>
						</i></a>
				</div>
				<hr>

			</div>
			<div class="col-md-3  my-auto shadow ">
				<div class="text-white  p-5 " style="background: #00004d;  border-radius:8px">
					<a href="person_report.php"><i class="fa fa-flag text-white">
							<h3 class="text-white">Report</h3>
						</i></a>
				</div>
				<hr>

				<div class=" text-white bg-danger p-5 mt-4 my-auto shadow  " style=" border-radius:8px">
					<a href="about.php"><i class="fa fa-info-circle text-white">
							<h3 class="text-white">About</h3>
						</i></a>
				</div>
				<hr>

			</div>


		</div>
		
	</div>

</body>

</html>