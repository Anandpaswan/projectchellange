	<!DOCTYPE html>
<html>
<head>
	<title>Billing</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
	body {
			width: 100%;
			height: 100vh;
			background: url('image/green.jpg');

			background-size: cover;
			overflow: hidden;

		}
		.main {
        text-align:center;
    }
    .marq {
        padding-top:10px;
       
    }
    .geek1 {
        font-size:46px;
        font-weight:bold;
        color:white;
        padding-bottom:2px;
		color: red;
	
    }
</style>
</head>
<body>
<div class = "main">

    <marquee class="marq"  loop=""  behavior="alternate" >
        <div class="geek1 ">Welcome to a Billing Page</div>
    </marquee>
   
</div>


	<div class="container">
		<div class="row">
			<div class="col-md-5 mt-5">
				<div class="card">
				<div class="card-header bg-success text-white">
					<h5 class="card-title text-center">Add Item</h5>
				</div>
				<div class="card-body " >
					
				
				<form method="post" action="billing_back.php" class="border-2" >
                    <div class="form-group ">
                        <label>Product Name</label>
                        <input type="text" name="product" required class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label>Rate</label>
                        <input type="text" name="rate" required class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="text" name="quantity" required class="form-control"/>
                    </div>
                    
                    <button type="ADD" class="btn btn-success btn  btn-block mt-3">ADD</button>
                </form>
			</div>
			</div>
		</div>


			<div class="col-md-7 mt-5">
				<div class="card">

				<div class="card-header bg-success text-white text-center">
					<h5>List Of Purchase Item</h5>
				</div>
				<div class="card-body">
				
				<table class="table table-success" cellspacing="0">
					<thead>
						<th>Product</th>
						<th>Rate</th>
						<th>Quantity</th>
						<th>Total Price</th>
						<th>Status</th>
					

					</thead>
					<tbody >
					<tbody>
                        <?php
                          require_once('db.php');
                            $data=$conn->query("SELECT* FROM billing_data");
                            while($rw=$data->fetch_assoc())
                            {


                            ?>
                            <tr>
                                <td><?php echo $rw['product_name']; ?></td>
                                <td><?php echo $rw['rate']; ?></td>
                                <td><?php echo $rw['quantity']; ?></td>
                                <td><?php echo $rw['rate']*$rw['quantity']; ?></td>
                                <td>
                             <a href="delete.php?name=<?php echo $rw['product_name']; ?>" class="btn btn-danger">
                              <i class="fa fa-trash"></i>
                            </a>
                            
                                </td>
                            </tr>
                            <?php  } ?>
                        </tbody>
					</tbody>
			
				</table>
<div class="cardd-footer">
				
				<button type="button" class="btn btn-success btn-block btn-lg mt-3" data-toggle="modal" data-target="#myModal">
Show Bill
</button>
							</div>


<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
	  

      <!-- Modal Header -->

      <div class="modal-header">
	  <h3 class="modal-title ml-2 mt-2 text-danger" >Show Bill</h3>
	  <button type="button" class="close" data-dismiss="modal">&times;</button>
	

      </div>
				
			
					
			<div class="modal-body">
						<form method="post" action="detail_log.php" class="border-2">
								<div class="form-group ">
									<label>Customer Name</label>
										<input type="text" name="pname" required class="form-control" placeholder="Enter  customer name...." />
								</div>
									<div class="form-group">
										<label>Mobile Number</label>
										<input type="text" name="mobile" required class="form-control" placeholder="Enter contact number" />
									</div>
									<div class="form-group">
										<label>Email Id</label>
										<input type="text" name="email" required class="form-control" placeholder="Enter email here" />
								</div>

						<button type="submit" class="btn btn-success btn-block" >Bill</button>

						</form>
										
										
			</div>
		</div>
	</div>
</div>

</body>
</html>